# BranchDebug — VS Code Extension

> AI root cause analysis. Click a suspect from the web app → land on the exact line instantly.

## How It Works

1. Run an analysis on [app.branchdebug.io](https://app.branchdebug.io)
2. Click **"⚡ Open in VS Code"** on any suspect card
3. VS Code opens, jumps to that exact file and line, highlights it with a confidence-coded gutter marker

## Setup

### 1. Install the extension
```
ext install branchdebug.branchdebug
```

### 2. Set your workspace root (one-time)
Open Command Palette (`Ctrl+Shift+P`) → **BranchDebug: Set Workspace Root**

Or let it auto-detect from your open workspace (usually works automatically).

### 3. That's it
Deep links from the web app will now open files directly in your editor.

---

## Deep Link Format

```
branchdebug://open?file=payments/validator.py&line=142&confidence=High
```

| Param        | Required | Description                          |
|-------------|----------|--------------------------------------|
| `file`      | ✓        | Relative path from project root      |
| `line`      | ✓        | 1-indexed line number                |
| `endLine`   |          | End of highlighted range             |
| `confidence`|          | High / Medium / Low (gutter color)   |
| `analysis`  |          | Analysis ID for sidebar context      |
| `mechanism` |          | Explanation shown in hover tooltip   |
| `change`    |          | What changed (shown in tooltip)      |
| `function`  |          | Function name                        |

---

## Commands

| Command | Description |
|---------|-------------|
| `BranchDebug: Set Workspace Root` | Manually set your project root |
| `BranchDebug: Analyze Current Branch` | Run analysis from inside VS Code |
| `BranchDebug: Clear Highlights` | Remove all gutter decorations |
| `BranchDebug: Open Settings` | Open extension settings |

---

## Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `branchdebug.workspaceRoot` | `""` | Absolute path to project root |
| `branchdebug.serverUrl` | `https://api.branchdebug.io` | For on-prem deployments, set to your server URL |
| `branchdebug.preferCursor` | `false` | Use Cursor instead of VS Code |
| `branchdebug.highlightDuration` | `0` | Auto-clear highlights after N seconds (0 = keep) |
| `branchdebug.autoDetectRoot` | `true` | Auto-detect root from workspace |

---

## On-Prem Setup

If your team uses the self-hosted Docker deployment:

```json
// .vscode/settings.json
{
  "branchdebug.serverUrl": "https://branchdebug.your-company.internal"
}
```

---

## Development

```bash
git clone https://github.com/branchdebug/vscode-extension
cd vscode-extension
npm install
npm run compile

# Press F5 in VS Code to launch Extension Development Host
```

### Test a deep link manually
Open VS Code's "Run" menu → "Open URL handler" → paste:
```
branchdebug://open?file=src/payments/validator.py&line=42&confidence=High&mechanism=Threshold%20change%20causes%20rejection
```

---

## Gutter Highlight Colors

| Confidence | Color  | Meaning              |
|-----------|--------|----------------------|
| High      | 🔴 Red    | Very likely the cause |
| Medium    | 🟡 Amber  | Possible cause        |
| Low       | 🔵 Blue   | Worth checking        |
