/**
 * Config Manager
 * ===============
 * Handles workspace root resolution with fallback chain:
 *
 * 1. Explicit user setting (branchdebug.workspaceRoot)
 * 2. Auto-detected from open VS Code workspace folders
 * 3. Git root detection (walks up from open file looking for .git)
 * 4. Prompt user to set manually
 *
 * Root is stored in VS Code's workspace settings so it persists
 * per-project without polluting global config.
 */

import * as vscode from "vscode";
import * as path from "path";
import * as fs from "fs";
import * as os from "os";

export class ConfigManager {
  constructor(private context: vscode.ExtensionContext) {}

  // ── Workspace root ─────────────────────────────────────────────────────────

  async resolveRoot(): Promise<string | null> {
    // 1. Explicit setting
    const explicit = vscode.workspace
      .getConfiguration("branchdebug")
      .get<string>("workspaceRoot", "");
    if (explicit && fs.existsSync(explicit)) {
      return explicit;
    }

    // 2. Auto-detect enabled + workspace folders available
    const autoDetect = vscode.workspace
      .getConfiguration("branchdebug")
      .get<boolean>("autoDetectRoot", true);

    if (autoDetect) {
      const detected = this.detectFromWorkspace();
      if (detected) return detected;
    }

    // 3. Walk up from active editor file looking for .git
    const gitRoot = this.detectFromGit();
    if (gitRoot) return gitRoot;

    return null;
  }

  async setWorkspaceRoot(root: string): Promise<void> {
    await vscode.workspace
      .getConfiguration("branchdebug")
      .update("workspaceRoot", root, vscode.ConfigurationTarget.Workspace);
  }

  async autoDetectAndSaveRoot(): Promise<string | null> {
    const root = this.detectFromWorkspace() ?? this.detectFromGit();
    if (root) {
      // Save to workspace config silently (don't overwrite explicit setting)
      const existing = vscode.workspace
        .getConfiguration("branchdebug")
        .get<string>("workspaceRoot", "");
      if (!existing) {
        await this.setWorkspaceRoot(root);
      }
      return root;
    }
    return null;
  }

  // ── Server config ──────────────────────────────────────────────────────────

  get serverUrl(): string {
    return vscode.workspace
      .getConfiguration("branchdebug")
      .get<string>("serverUrl", "https://api.branchdebug.io");
  }

  get preferCursor(): boolean {
    return vscode.workspace
      .getConfiguration("branchdebug")
      .get<boolean>("preferCursor", false);
  }

  // ── Auth token (stored in Secret Storage — never in settings) ─────────────

  async getAuthToken(): Promise<string | null> {
    return this.context.secrets.get("branchdebug.authToken") ?? null;
  }

  async setAuthToken(token: string): Promise<void> {
    await this.context.secrets.store("branchdebug.authToken", token);
  }

  async clearAuthToken(): Promise<void> {
    await this.context.secrets.delete("branchdebug.authToken");
  }

  // ── Deep link URL builder ──────────────────────────────────────────────────

  /**
   * Generates a branchdebug:// deep link for a suspect.
   * Used by the web app to create clickable links.
   */
  static buildDeepLink(params: {
    file:        string;
    line:        number;
    endLine?:    number;
    confidence:  string;
    analysisId?: string;
    mechanism?:  string;
    change?:     string;
    fn?:         string;
    preferCursor?: boolean;
  }): string {
    const q = new URLSearchParams({
      file:       params.file,
      line:       String(params.line),
      confidence: params.confidence,
    });

    if (params.endLine)    q.set("endLine",   String(params.endLine));
    if (params.analysisId) q.set("analysis",  params.analysisId);
    if (params.mechanism)  q.set("mechanism", encodeURIComponent(params.mechanism));
    if (params.change)     q.set("change",    encodeURIComponent(params.change));
    if (params.fn)         q.set("function",  encodeURIComponent(params.fn));

    return `branchdebug://open?${q.toString()}`;
  }

  // ── Private helpers ────────────────────────────────────────────────────────

  private detectFromWorkspace(): string | null {
    const folders = vscode.workspace.workspaceFolders;
    if (!folders || folders.length === 0) return null;

    // Prefer folder with a .git directory
    for (const folder of folders) {
      const gitPath = path.join(folder.uri.fsPath, ".git");
      if (fs.existsSync(gitPath)) {
        return folder.uri.fsPath;
      }
    }

    // Fall back to first folder
    return folders[0].uri.fsPath;
  }

  private detectFromGit(): string | null {
    const editor = vscode.window.activeTextEditor;
    if (!editor) return null;

    let dir = path.dirname(editor.document.uri.fsPath);
    const root = path.parse(dir).root;

    // Walk up looking for .git
    while (dir !== root) {
      if (fs.existsSync(path.join(dir, ".git"))) {
        return dir;
      }
      dir = path.dirname(dir);
    }

    return null;
  }
}
