/**
 * BranchDebug VS Code Extension
 * ================================
 * Entry point. Registers:
 *   - URI handler: branchdebug://open?file=...&line=...
 *   - Commands: set root, analyze branch, clear highlights
 *   - Sidebar webview: shows last analysis results
 *   - Status bar item: shows connection status
 */

import * as vscode from "vscode";
import * as path from "path";
import { UriHandler } from "./uriHandler";
import { ConfigManager } from "./configManager";
import { HighlightManager } from "./highlightManager";
import { SidebarProvider } from "./sidebarProvider";
import { StatusBarManager } from "./statusBarManager";
import { GitHelper } from "./gitHelper";
import { BranchDebugClient } from "./client";

export function activate(context: vscode.ExtensionContext) {
  console.log("BranchDebug extension activated");

  // ── Core services ──────────────────────────────────────────────────────────
  const config       = new ConfigManager(context);
  const highlights   = new HighlightManager();
  const statusBar    = new StatusBarManager();
  const client       = new BranchDebugClient(config);
  const sidebar      = new SidebarProvider(context, highlights);

  // ── URI Handler ────────────────────────────────────────────────────────────
  // Handles: branchdebug://open?file=payments/validator.py&line=142&confidence=High
  const uriHandler = new UriHandler(config, highlights, sidebar);
  context.subscriptions.push(
    vscode.window.registerUriHandler(uriHandler)
  );

  // ── Sidebar webview ────────────────────────────────────────────────────────
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(
      "branchdebug.resultsView",
      sidebar
    )
  );

  // ── Commands ───────────────────────────────────────────────────────────────

  // Command: Set workspace root manually
  context.subscriptions.push(
    vscode.commands.registerCommand(
      "branchdebug.setWorkspaceRoot",
      async () => {
        const folders = vscode.workspace.workspaceFolders;
        const defaultPath = folders?.[0]?.uri.fsPath ?? "";

        const input = await vscode.window.showInputBox({
          prompt: "Enter absolute path to your project root",
          value: defaultPath,
          placeHolder: "/Users/jasmine/myproject",
        });

        if (input) {
          await config.setWorkspaceRoot(input);
          vscode.window.showInformationMessage(
            `BranchDebug: Workspace root set to ${input}`
          );
          statusBar.update("ready", input);
        }
      }
    )
  );

  // Command: Analyze current branch
  context.subscriptions.push(
    vscode.commands.registerCommand(
      "branchdebug.analyzeCurrentBranch",
      async () => {
        const root = await config.resolveRoot();
        if (!root) {
          const action = await vscode.window.showErrorMessage(
            "BranchDebug: No workspace root configured.",
            "Set Root"
          );
          if (action === "Set Root") {
            vscode.commands.executeCommand("branchdebug.setWorkspaceRoot");
          }
          return;
        }

        // Get diff from git
        const diff = await GitHelper.getCurrentBranchDiff(root);
        if (!diff) {
          vscode.window.showWarningMessage(
            "BranchDebug: No diff found. Make sure you have uncommitted changes or a branch checked out."
          );
          return;
        }

        // Ask for failure description
        const note = await vscode.window.showInputBox({
          prompt: "Describe what broke (plain English)",
          placeHolder: "e.g. API throwing 500 on /checkout after this deploy",
        });

        if (!note) return;

        // Show progress
        await vscode.window.withProgress(
          {
            location: vscode.ProgressLocation.Notification,
            title: "BranchDebug: Analyzing...",
            cancellable: false,
          },
          async () => {
            try {
              const result = await client.analyze({ diff, note });
              sidebar.showResults(result);
              vscode.window.showInformationMessage(
                `BranchDebug: Found ${result.suspects.length} suspect(s). Check the sidebar.`
              );
            } catch (err: any) {
              vscode.window.showErrorMessage(
                `BranchDebug: Analysis failed — ${err.message}`
              );
            }
          }
        );
      }
    )
  );

  // Command: Clear all highlights
  context.subscriptions.push(
    vscode.commands.registerCommand("branchdebug.clearHighlights", () => {
      highlights.clearAll();
      vscode.window.showInformationMessage("BranchDebug: Highlights cleared.");
    })
  );

  // Command: Open settings
  context.subscriptions.push(
    vscode.commands.registerCommand("branchdebug.openSettings", () => {
      vscode.commands.executeCommand(
        "workbench.action.openSettings",
        "branchdebug"
      );
    })
  );

  // ── Auto-detect workspace root on activation ───────────────────────────────
  config.autoDetectAndSaveRoot().then((root) => {
    if (root) {
      statusBar.update("ready", root);
    } else {
      statusBar.update("no-root");
    }
  });

  // ── Workspace folder change listener ──────────────────────────────────────
  context.subscriptions.push(
    vscode.workspace.onDidChangeWorkspaceFolders(() => {
      config.autoDetectAndSaveRoot();
    })
  );

  statusBar.register(context);
  console.log("BranchDebug: All handlers registered.");
}

export function deactivate() {
  console.log("BranchDebug deactivated.");
}
