/**
 * Git Helper
 * ===========
 * Gets the current branch diff using VS Code's built-in git extension.
 * Falls back to running `git diff` via child process.
 */

import * as vscode from "vscode";
import * as cp from "child_process";

export class GitHelper {
  static async getCurrentBranchDiff(root: string): Promise<string | null> {
    // Try VS Code git extension first
    try {
      const gitExt = vscode.extensions.getExtension("vscode.git");
      if (gitExt) {
        const api = gitExt.exports.getAPI(1);
        const repo = api.repositories.find(
          (r: any) => r.rootUri.fsPath === root
        );
        if (repo) {
          const changes = repo.state.workingTreeChanges;
          if (changes.length === 0) {
            // Try index (staged) changes
            const staged = repo.state.indexChanges;
            if (staged.length === 0) return null;
          }
        }
      }
    } catch {}

    // Fall back to running git diff directly
    return new Promise((resolve) => {
      cp.exec(
        "git diff HEAD",
        { cwd: root, maxBuffer: 10 * 1024 * 1024 },
        (err, stdout) => {
          if (err || !stdout.trim()) {
            // Try diff against main/master
            cp.exec(
              "git diff main...HEAD 2>/dev/null || git diff master...HEAD",
              { cwd: root, maxBuffer: 10 * 1024 * 1024 },
              (err2, stdout2) => {
                resolve(stdout2?.trim() || null);
              }
            );
            return;
          }
          resolve(stdout.trim());
        }
      );
    });
  }

  static async getCurrentBranch(root: string): Promise<string | null> {
    return new Promise((resolve) => {
      cp.exec(
        "git rev-parse --abbrev-ref HEAD",
        { cwd: root },
        (err, stdout) => resolve(err ? null : stdout.trim())
      );
    });
  }
}


/**
 * BranchDebug API Client
 * =======================
 * Calls the BranchDebug server /analyze endpoint.
 * Auth token retrieved from VS Code Secret Storage.
 */

import { ConfigManager } from "./configManager";

export interface AnalyzeRequest {
  diff:    string;
  note:    string;
  branch?: string;
}

export class BranchDebugClient {
  constructor(private config: ConfigManager) {}

  async analyze(req: AnalyzeRequest): Promise<import("./sidebarProvider").AnalysisResult> {
    const token = await this.config.getAuthToken();

    const response = await fetch(`${this.config.serverUrl}/analyze/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({
        diff:   req.diff,
        note:   req.note,
        branch: req.branch,
      }),
    });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`Server returned ${response.status}: ${body}`);
    }

    const data = await response.json() as any;
    return {
      analysisId:     data.analysis_id,
      summary:        data.summary,
      suspects:       data.suspects,
      recommendation: data.recommendation,
      timestamp:      Date.now(),
      branch:         req.branch,
    };
  }
}


/**
 * Status Bar Manager
 * ===================
 * Shows BranchDebug connection status in the VS Code status bar.
 *
 * States:
 *   ready     → "⚡ BranchDebug" (green)
 *   no-root   → "⚡ BranchDebug: Set root" (warning)
 *   analyzing → "⟳ BranchDebug: Analyzing..." (spinner)
 *   error     → "✕ BranchDebug" (red)
 */

export class StatusBarManager {
  private item?: vscode.StatusBarItem;

  register(context: vscode.ExtensionContext): void {
    this.item = vscode.window.createStatusBarItem(
      vscode.StatusBarAlignment.Left,
      100
    );
    this.item.command = "branchdebug.openSettings";
    this.update("no-root");
    this.item.show();
    context.subscriptions.push(this.item);
  }

  update(state: "ready" | "no-root" | "analyzing" | "error", detail?: string): void {
    if (!this.item) return;

    switch (state) {
      case "ready":
        this.item.text    = `⚡ BranchDebug`;
        this.item.tooltip = `BranchDebug ready — root: ${detail ?? "auto"}`;
        this.item.color   = new vscode.ThemeColor("statusBarItem.prominentForeground");
        break;
      case "no-root":
        this.item.text    = `⚡ BranchDebug: Set root`;
        this.item.tooltip = "Click to configure BranchDebug workspace root";
        this.item.color   = new vscode.ThemeColor("statusBarItem.warningForeground");
        this.item.command = "branchdebug.setWorkspaceRoot";
        break;
      case "analyzing":
        this.item.text    = `$(sync~spin) BranchDebug: Analyzing...`;
        this.item.tooltip = "BranchDebug analysis in progress";
        this.item.color   = undefined;
        break;
      case "error":
        this.item.text    = `$(error) BranchDebug`;
        this.item.tooltip = detail ?? "BranchDebug error";
        this.item.color   = new vscode.ThemeColor("statusBarItem.errorForeground");
        break;
    }
  }
}
