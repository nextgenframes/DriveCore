/**
 * Highlight Manager
 * ==================
 * Manages gutter decorations on suspect lines.
 *
 * Colors:
 *   High      → red   (#ff4444) — likely cause
 *   Medium    → amber (#ffaa00) — possible cause
 *   Low       → blue  (#44aaff) — worth checking
 *
 * Features:
 *   - Whole-line background tint
 *   - Gutter color bar (left edge)
 *   - Overview ruler marker (scrollbar)
 *   - Hover tooltip with mechanism explanation
 *   - Auto-clear after configurable duration
 *   - Stack multiple suspects across multiple files
 */

import * as vscode from "vscode";

export interface HighlightOptions {
  startLine:   number;   // 0-indexed
  endLine:     number;   // 0-indexed
  confidence:  string;   // High | Medium | Low
  message:     vscode.MarkdownString;
}

interface ActiveDecoration {
  type:   vscode.TextEditorDecorationType;
  editor: vscode.TextEditor;
  timer?: NodeJS.Timeout;
}

const CONFIDENCE_STYLES: Record<string, {
  bg: string; border: string; ruler: string; overview: string;
}> = {
  High: {
    bg:       "rgba(255, 68, 68, 0.12)",
    border:   "#ff4444",
    ruler:    "#ff4444",
    overview: "#ff4444",
  },
  Medium: {
    bg:       "rgba(255, 170, 0, 0.10)",
    border:   "#ffaa00",
    ruler:    "#ffaa00",
    overview: "#ffaa00",
  },
  Low: {
    bg:       "rgba(68, 170, 255, 0.08)",
    border:   "#44aaff",
    ruler:    "#44aaff",
    overview: "#44aaff",
  },
};

export class HighlightManager {
  private active: ActiveDecoration[] = [];

  applyToEditor(editor: vscode.TextEditor, opts: HighlightOptions): void {
    const style = CONFIDENCE_STYLES[opts.confidence] ?? CONFIDENCE_STYLES["Medium"];

    const decorationType = vscode.window.createTextEditorDecorationType({
      // Whole-line background tint
      isWholeLine:     true,
      backgroundColor: style.bg,

      // Left gutter color bar
      borderWidth:  "0 0 0 3px",
      borderStyle:  "solid",
      borderColor:  style.border,

      // Scrollbar overview ruler marker
      overviewRulerColor: style.ruler,
      overviewRulerLane:  vscode.OverviewRulerLane.Right,

      // Light mode fallback
      light: {
        backgroundColor: style.bg.replace(/[\d.]+\)$/, "0.08)"),
        borderColor:     style.border,
      },
    });

    const ranges: vscode.DecorationOptions[] = [];
    for (let l = opts.startLine; l <= opts.endLine; l++) {
      const line   = editor.document.lineAt(Math.min(l, editor.document.lineCount - 1));
      const range  = new vscode.Range(line.range.start, line.range.end);
      ranges.push({
        range,
        hoverMessage: opts.message,
      });
    }

    editor.setDecorations(decorationType, ranges);

    // Track for cleanup
    const entry: ActiveDecoration = { type: decorationType, editor };

    // Auto-clear if duration is set
    const duration = vscode.workspace
      .getConfiguration("branchdebug")
      .get<number>("highlightDuration", 0);

    if (duration > 0) {
      entry.timer = setTimeout(() => {
        decorationType.dispose();
        this.active = this.active.filter((d) => d !== entry);
      }, duration * 1000);
    }

    this.active.push(entry);
  }

  clearAll(): void {
    for (const d of this.active) {
      if (d.timer) clearTimeout(d.timer);
      d.type.dispose();
    }
    this.active = [];
  }

  clearForEditor(editor: vscode.TextEditor): void {
    const toRemove = this.active.filter((d) => d.editor === editor);
    for (const d of toRemove) {
      if (d.timer) clearTimeout(d.timer);
      d.type.dispose();
    }
    this.active = this.active.filter((d) => d.editor !== editor);
  }

  get activeCount(): number {
    return this.active.length;
  }
}
