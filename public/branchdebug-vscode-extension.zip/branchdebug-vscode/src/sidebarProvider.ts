/**
 * Sidebar Provider
 * =================
 * Renders the BranchDebug results panel in the VS Code sidebar.
 * Shows the last analysis: summary, ranked suspects, recommendation.
 * Clicking a suspect fires the deep link → jumps to that line.
 */

import * as vscode from "vscode";
import { HighlightManager } from "./highlightManager";
import { DeepLinkParams } from "./uriHandler";
import { ConfigManager } from "./configManager";

export interface AnalysisResult {
  analysisId:  string;
  summary:     string;
  suspects:    Suspect[];
  recommendation: string;
  branch?:     string;
  timestamp?:  number;
}

export interface Suspect {
  file:       string;
  function:   string;
  confidence: string;
  change:     string;
  mechanism:  string;
  line?:      number;
  endLine?:   number;
}

export class SidebarProvider implements vscode.WebviewViewProvider {
  private _view?: vscode.WebviewView;
  private _lastResult?: AnalysisResult;
  private _activeSuspectFile?: string;

  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly highlights: HighlightManager
  ) {}

  resolveWebviewView(
    webviewView: vscode.WebviewView,
    _context: vscode.WebviewViewResolveContext,
    _token: vscode.CancellationToken
  ): void {
    this._view = webviewView;

    webviewView.webview.options = {
      enableScripts: true,
      localResourceRoots: [this.context.extensionUri],
    };

    webviewView.webview.html = this.getIdleHtml();

    // Handle messages from the webview (suspect clicks)
    webviewView.webview.onDidReceiveMessage((msg) => {
      if (msg.type === "openSuspect") {
        const suspect: Suspect = msg.suspect;
        const link = ConfigManager.buildDeepLink({
          file:       suspect.file,
          line:       suspect.line ?? 1,
          endLine:    suspect.endLine,
          confidence: suspect.confidence,
          analysisId: this._lastResult?.analysisId,
          mechanism:  suspect.mechanism,
          change:     suspect.change,
          fn:         suspect.function,
        });
        // Trigger our own URI handler
        vscode.env.openExternal(vscode.Uri.parse(link));
      }

      if (msg.type === "clearHighlights") {
        this.highlights.clearAll();
      }

      if (msg.type === "copyLink") {
        const suspect: Suspect = msg.suspect;
        const link = ConfigManager.buildDeepLink({
          file:       suspect.file,
          line:       suspect.line ?? 1,
          confidence: suspect.confidence,
          mechanism:  suspect.mechanism,
        });
        vscode.env.clipboard.writeText(link);
        vscode.window.showInformationMessage("BranchDebug: Link copied to clipboard.");
      }
    });
  }

  showResults(result: AnalysisResult): void {
    this._lastResult = result;
    if (this._view) {
      this._view.webview.html = this.getResultsHtml(result);
      this._view.show(true);
    }
  }

  highlightSuspect(params: DeepLinkParams): void {
    this._activeSuspectFile = params.file;
    if (this._view && this._lastResult) {
      this._view.webview.postMessage({
        type:     "activateSuspect",
        file:     params.file,
        line:     params.line,
      });
    }
  }

  // ── HTML templates ─────────────────────────────────────────────────────────

  private getIdleHtml(): string {
    return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  body {
    font-family: var(--vscode-font-family);
    font-size: var(--vscode-font-size);
    color: var(--vscode-foreground);
    padding: 12px;
    margin: 0;
  }
  .idle {
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    height: 180px; gap: 10px;
    opacity: 0.5; text-align: center;
  }
  .idle-icon { font-size: 32px; }
  .idle-text { font-size: 11px; line-height: 1.6; }
  .hint {
    font-size: 10px; margin-top: 16px;
    color: var(--vscode-descriptionForeground);
    text-align: center; line-height: 1.6;
  }
</style>
</head>
<body>
  <div class="idle">
    <div class="idle-icon">⚡</div>
    <div class="idle-text">
      No analysis yet.<br/>
      Run BranchDebug from<br/>the web app or command palette.
    </div>
  </div>
  <div class="hint">
    Tip: Use <code>Ctrl+Shift+P</code> →<br/>
    "BranchDebug: Analyze Current Branch"
  </div>
</body>
</html>`;
  }

  private getResultsHtml(result: AnalysisResult): string {
    const suspects = result.suspects.map((s, i) => this.suspectCard(s, i)).join("");
    const time = result.timestamp
      ? new Date(result.timestamp).toLocaleTimeString()
      : "just now";

    return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  * { box-sizing: border-box; }
  body {
    font-family: var(--vscode-font-family);
    font-size: var(--vscode-font-size);
    color: var(--vscode-foreground);
    padding: 10px; margin: 0;
    background: var(--vscode-sideBar-background);
  }
  .header {
    margin-bottom: 10px;
    padding-bottom: 8px;
    border-bottom: 1px solid var(--vscode-widget-border);
  }
  .label {
    font-size: 9px; letter-spacing: 2px;
    text-transform: uppercase;
    color: var(--vscode-descriptionForeground);
    margin-bottom: 4px;
  }
  .summary {
    font-size: 11px; line-height: 1.5;
    color: var(--vscode-foreground);
  }
  .time { font-size: 9px; color: var(--vscode-descriptionForeground); margin-top: 4px; }

  .suspects { display: flex; flex-direction: column; gap: 6px; margin-bottom: 10px; }

  .suspect {
    border-radius: 5px; padding: 8px 10px;
    border: 1px solid var(--vscode-widget-border);
    background: var(--vscode-editor-background);
    cursor: pointer; transition: all 0.15s;
  }
  .suspect:hover { border-color: var(--vscode-focusBorder); }
  .suspect.active { border-color: var(--vscode-focusBorder); background: var(--vscode-list-activeSelectionBackground); }

  .suspect-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4px; }
  .suspect-file { font-size: 10px; font-weight: 600; color: var(--vscode-foreground); word-break: break-all; }
  .suspect-fn { font-size: 9px; color: var(--vscode-descriptionForeground); margin-top: 1px; }

  .badge {
    font-size: 9px; padding: 1px 6px; border-radius: 3px;
    font-weight: 700; flex-shrink: 0; margin-left: 6px;
  }
  .badge-High   { background: rgba(255,68,68,0.15);  color: #ff6666; }
  .badge-Medium { background: rgba(255,170,0,0.15); color: #ffaa44; }
  .badge-Low    { background: rgba(68,170,255,0.15); color: #66aaff; }

  .mechanism { font-size: 10px; color: var(--vscode-descriptionForeground); line-height: 1.5; margin-top: 4px; }

  .actions { display: flex; gap: 4px; margin-top: 6px; }
  .btn {
    font-size: 9px; padding: 2px 8px; border-radius: 3px; cursor: pointer;
    border: 1px solid var(--vscode-button-border, transparent);
    background: var(--vscode-button-secondaryBackground);
    color: var(--vscode-button-secondaryForeground);
    font-family: inherit;
  }
  .btn:hover { background: var(--vscode-button-secondaryHoverBackground); }
  .btn-primary {
    background: var(--vscode-button-background);
    color: var(--vscode-button-foreground);
  }

  .recommendation {
    background: var(--vscode-editor-background);
    border: 1px solid var(--vscode-widget-border);
    border-radius: 5px; padding: 8px 10px; margin-top: 6px;
  }
  .rec-label { font-size: 9px; letter-spacing: 2px; text-transform: uppercase; color: #ffaa44; margin-bottom: 4px; }
  .rec-text { font-size: 10px; line-height: 1.5; color: var(--vscode-foreground); }

  .footer { margin-top: 10px; text-align: center; }
</style>
</head>
<body>
<div class="header">
  <div class="label">BranchDebug — Last Analysis</div>
  <div class="summary">${escHtml(result.summary)}</div>
  <div class="time">Analyzed ${escHtml(time)} · ${result.suspects.length} suspect(s)</div>
</div>

<div class="suspects">
${suspects}
</div>

<div class="recommendation">
  <div class="rec-label">Recommendation</div>
  <div class="rec-text">${escHtml(result.recommendation)}</div>
</div>

<div class="footer">
  <button class="btn" onclick="clearHighlights()">Clear highlights</button>
</div>

<script>
  const vscode = acquireVsCodeApi();

  function openSuspect(idx) {
    const suspects = ${JSON.stringify(result.suspects)};
    vscode.postMessage({ type: 'openSuspect', suspect: suspects[idx] });
    document.querySelectorAll('.suspect').forEach((el, i) => {
      el.classList.toggle('active', i === idx);
    });
  }

  function copyLink(idx) {
    const suspects = ${JSON.stringify(result.suspects)};
    vscode.postMessage({ type: 'copyLink', suspect: suspects[idx] });
  }

  function clearHighlights() {
    vscode.postMessage({ type: 'clearHighlights' });
  }

  window.addEventListener('message', e => {
    if (e.data.type === 'activateSuspect') {
      document.querySelectorAll('.suspect').forEach((el, i) => {
        const s = ${JSON.stringify(result.suspects)}[i];
        el.classList.toggle('active', s.file === e.data.file && s.line === e.data.line);
      });
    }
  });
</script>
</body>
</html>`;

    function escHtml(str: string) {
      return str
        .replace(/&/g, "&amp;").replace(/</g, "&lt;")
        .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }
  }

  private suspectCard(s: Suspect, i: number): string {
    const esc = (str: string) => str
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");

    return `
<div class="suspect" onclick="openSuspect(${i})">
  <div class="suspect-header">
    <div>
      <div class="suspect-file">${esc(s.file)}</div>
      <div class="suspect-fn">${esc(s.function)}()</div>
    </div>
    <span class="badge badge-${s.confidence}">${esc(s.confidence)}</span>
  </div>
  <div class="mechanism">${esc(s.mechanism)}</div>
  <div class="actions">
    <button class="btn btn-primary" onclick="event.stopPropagation(); openSuspect(${i})">⚡ Jump to line</button>
    <button class="btn" onclick="event.stopPropagation(); copyLink(${i})">Copy link</button>
  </div>
</div>`;
  }
}
