/**
 * URI Handler
 * ============
 * Handles: branchdebug://open?file=payments/validator.py&line=142&confidence=High&analysis=abc123
 *
 * Flow:
 *   1. Parse URI params
 *   2. Resolve relative path → absolute using workspace root
 *   3. Open file in editor
 *   4. Jump to exact line
 *   5. Highlight suspect lines with confidence-coded colors
 *   6. Update sidebar with this finding
 */

import * as vscode from "vscode";
import * as path from "path";
import * as fs from "fs";
import { ConfigManager } from "./configManager";
import { HighlightManager } from "./highlightManager";
import { SidebarProvider } from "./sidebarProvider";

export interface DeepLinkParams {
  file: string;           // Relative path: "payments/validator.py"
  line: number;           // 1-indexed line number
  endLine?: number;       // Optional range end
  confidence?: string;    // High | Medium | Low
  analysisId?: string;    // For tracking / sidebar context
  mechanism?: string;     // Why this line is suspect
  change?: string;        // What changed
  function?: string;      // Function name
}

export class UriHandler implements vscode.UriHandler {
  constructor(
    private config: ConfigManager,
    private highlights: HighlightManager,
    private sidebar: SidebarProvider
  ) {}

  async handleUri(uri: vscode.Uri): Promise<void> {
    // Only handle branchdebug://open
    if (uri.authority !== "open") {
      vscode.window.showWarningMessage(
        `BranchDebug: Unknown URI command "${uri.authority}"`
      );
      return;
    }

    const params = this.parseParams(uri);
    if (!params) return;

    // Resolve workspace root
    const root = await this.config.resolveRoot();
    if (!root) {
      const action = await vscode.window.showErrorMessage(
        "BranchDebug: Workspace root not set. Cannot resolve file path.",
        "Set Root Now"
      );
      if (action === "Set Root Now") {
        vscode.commands.executeCommand("branchdebug.setWorkspaceRoot");
      }
      return;
    }

    // Resolve absolute path
    const absPath = this.resolveAbsPath(root, params.file);
    if (!absPath) {
      vscode.window.showErrorMessage(
        `BranchDebug: File not found — "${params.file}" not in ${root}`
      );
      return;
    }

    // Open file and jump to line
    try {
      await this.openFileAtLine(absPath, params);
    } catch (err: any) {
      vscode.window.showErrorMessage(
        `BranchDebug: Could not open file — ${err.message}`
      );
    }
  }

  // ── Private helpers ────────────────────────────────────────────────────────

  private parseParams(uri: vscode.Uri): DeepLinkParams | null {
    const q = new URLSearchParams(uri.query);

    const file = q.get("file");
    const lineStr = q.get("line");

    if (!file || !lineStr) {
      vscode.window.showErrorMessage(
        "BranchDebug: Invalid deep link — missing file or line param."
      );
      return null;
    }

    const line = parseInt(lineStr, 10);
    if (isNaN(line) || line < 1) {
      vscode.window.showErrorMessage(
        `BranchDebug: Invalid line number "${lineStr}"`
      );
      return null;
    }

    return {
      file,
      line,
      endLine:     q.get("endLine")    ? parseInt(q.get("endLine")!, 10) : undefined,
      confidence:  q.get("confidence") ?? "Medium",
      analysisId:  q.get("analysis")   ?? undefined,
      mechanism:   q.get("mechanism")  ? decodeURIComponent(q.get("mechanism")!) : undefined,
      change:      q.get("change")     ? decodeURIComponent(q.get("change")!) : undefined,
      function:    q.get("function")   ? decodeURIComponent(q.get("function")!) : undefined,
    };
  }

  private resolveAbsPath(root: string, relFile: string): string | null {
    // Try direct join first
    const direct = path.join(root, relFile);
    if (fs.existsSync(direct)) return direct;

    // Try stripping leading a/ b/ from git diff paths
    const stripped = relFile.replace(/^[ab]\//, "");
    const strippedPath = path.join(root, stripped);
    if (fs.existsSync(strippedPath)) return strippedPath;

    // Search up to 2 levels deep for filename match (fallback)
    const filename = path.basename(relFile);
    const found = this.findFile(root, filename, 2);
    if (found) return found;

    return null;
  }

  private findFile(dir: string, filename: string, maxDepth: number): string | null {
    if (maxDepth < 0) return null;
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.name.startsWith(".") || entry.name === "node_modules") continue;
        const full = path.join(dir, entry.name);
        if (entry.isFile() && entry.name === filename) return full;
        if (entry.isDirectory()) {
          const found = this.findFile(full, filename, maxDepth - 1);
          if (found) return found;
        }
      }
    } catch {}
    return null;
  }

  private async openFileAtLine(absPath: string, params: DeepLinkParams) {
    const fileUri = vscode.Uri.file(absPath);
    const doc     = await vscode.workspace.openTextDocument(fileUri);
    const editor  = await vscode.window.showTextDocument(doc, {
      viewColumn: vscode.ViewColumn.One,
      preserveFocus: false,
    });

    // Jump to line (0-indexed internally)
    const lineIndex = params.line - 1;
    const endIndex  = params.endLine ? params.endLine - 1 : lineIndex;
    const position  = new vscode.Position(lineIndex, 0);

    editor.selection = new vscode.Selection(position, position);
    editor.revealRange(
      new vscode.Range(lineIndex, 0, endIndex, 0),
      vscode.TextEditorRevealType.InCenterIfOutsideViewport
    );

    // Apply gutter highlights
    this.highlights.applyToEditor(editor, {
      startLine: lineIndex,
      endLine:   endIndex,
      confidence: params.confidence ?? "Medium",
      message:   this.buildHoverMessage(params),
    });

    // Update sidebar with what we just jumped to
    this.sidebar.highlightSuspect(params);

    // Show inline notification with mechanism
    if (params.mechanism) {
      vscode.window.showInformationMessage(
        `BranchDebug [${params.confidence}]: ${params.mechanism}`
      );
    }
  }

  private buildHoverMessage(params: DeepLinkParams): vscode.MarkdownString {
    const md = new vscode.MarkdownString();
    md.isTrusted = true;
    md.appendMarkdown(`**BranchDebug** — ${params.confidence ?? "?"} confidence\n\n`);
    if (params.function) {
      md.appendMarkdown(`**Function:** \`${params.function}\`\n\n`);
    }
    if (params.change) {
      md.appendMarkdown(`**Change:** ${params.change}\n\n`);
    }
    if (params.mechanism) {
      md.appendMarkdown(`**Why this causes the failure:** ${params.mechanism}\n\n`);
    }
    md.appendMarkdown(
      `[Clear highlights](command:branchdebug.clearHighlights)`
    );
    return md;
  }
}
