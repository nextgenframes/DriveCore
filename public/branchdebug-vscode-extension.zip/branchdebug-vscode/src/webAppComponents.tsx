/**
 * BranchDebug Web App — Deep Link Button
 * ========================================
 * Drop this component into the existing result cards.
 * Generates branchdebug:// links and handles the click.
 *
 * Usage:
 *   <OpenInEditorButton suspect={suspect} analysisId={analysisId} />
 */

import { useState } from "react";

export interface Suspect {
  file:       string;
  function:   string;
  confidence: "High" | "Medium" | "Low";
  change:     string;
  mechanism:  string;
  line?:      number;
  endLine?:   number;
}

interface OpenInEditorButtonProps {
  suspect:    Suspect;
  analysisId: string;
}

type EditorTarget = "vscode" | "cursor" | "both";

// Generate branchdebug:// deep link
function buildDeepLink(suspect: Suspect, analysisId: string): string {
  const params = new URLSearchParams({
    file:       suspect.file,
    line:       String(suspect.line ?? 1),
    confidence: suspect.confidence,
    analysis:   analysisId,
    mechanism:  suspect.mechanism,
    change:     suspect.change,
    function:   suspect.function,
  });

  if (suspect.endLine) {
    params.set("endLine", String(suspect.endLine));
  }

  return `branchdebug://open?${params.toString()}`;
}

// Copy-to-clipboard sharable link
function buildShareLink(suspect: Suspect, analysisId: string): string {
  const base   = window.location.origin;
  const params = new URLSearchParams({
    analysisId,
    file:       suspect.file,
    line:       String(suspect.line ?? 1),
    confidence: suspect.confidence,
  });
  return `${base}/share?${params.toString()}`;
}

export function OpenInEditorButton({ suspect, analysisId }: OpenInEditorButtonProps) {
  const [status, setStatus]   = useState<"idle" | "opening" | "error" | "copied">("idle");
  const [showMenu, setShowMenu] = useState(false);

  const openInEditor = (target: EditorTarget = "vscode") => {
    setStatus("opening");
    setShowMenu(false);

    const link = buildDeepLink(suspect, analysisId);

    // Try to open the branchdebug:// URI
    // The browser will prompt if the extension isn't installed
    try {
      window.location.href = link;

      // If nothing happens after 1s, the extension probably isn't installed
      setTimeout(() => {
        setStatus("idle");
      }, 1000);
    } catch {
      setStatus("error");
      setTimeout(() => setStatus("idle"), 3000);
    }
  };

  const copyShareLink = async () => {
    const link = buildShareLink(suspect, analysisId);
    await navigator.clipboard.writeText(link);
    setStatus("copied");
    setTimeout(() => setStatus("idle"), 2000);
  };

  const confidenceColor = {
    High:   "#ff4444",
    Medium: "#ffaa00",
    Low:    "#44aaff",
  }[suspect.confidence];

  return (
    <div style={{ display: "flex", gap: "6px", alignItems: "center", marginTop: "10px", position: "relative" }}>

      {/* Primary: Open in VS Code */}
      <button
        onClick={() => openInEditor("vscode")}
        disabled={status === "opening"}
        style={{
          display: "flex", alignItems: "center", gap: "6px",
          padding: "6px 14px",
          background: status === "opening"
            ? "rgba(74,240,196,0.1)"
            : "linear-gradient(135deg, #4af0c4, #2ad0a4)",
          border: "none", borderRadius: "6px",
          color: status === "opening" ? "#4af0c4" : "#001a0d",
          fontSize: "11px", fontWeight: 700, cursor: "pointer",
          fontFamily: "inherit", letterSpacing: "0.5px",
          transition: "all 0.2s",
          boxShadow: "0 2px 8px rgba(74,240,196,0.2)",
        }}
      >
        <span style={{ fontSize: "13px" }}>
          {status === "opening" ? "⟳" : "⚡"}
        </span>
        {status === "opening" ? "Opening..." : "Open in VS Code"}
      </button>

      {/* Dropdown arrow for Cursor option */}
      <button
        onClick={() => setShowMenu(!showMenu)}
        style={{
          padding: "6px 8px",
          background: "#0d1520", border: "1px solid #1a2d40",
          borderRadius: "6px", color: "#4a6070",
          fontSize: "11px", cursor: "pointer",
          fontFamily: "inherit",
        }}
        title="More editor options"
      >
        ▾
      </button>

      {/* Copy share link */}
      <button
        onClick={copyShareLink}
        style={{
          padding: "6px 12px",
          background: "transparent", border: "1px solid #1a2d40",
          borderRadius: "6px",
          color: status === "copied" ? "#4af0c4" : "#4a6070",
          fontSize: "11px", cursor: "pointer",
          fontFamily: "inherit", transition: "all 0.2s",
        }}
        title="Copy shareable link"
      >
        {status === "copied" ? "✓ Copied" : "Copy link"}
      </button>

      {/* Dropdown menu */}
      {showMenu && (
        <div style={{
          position: "absolute", top: "100%", left: 0, marginTop: "4px",
          background: "#0d1520", border: "1px solid #1a2d40",
          borderRadius: "8px", padding: "6px",
          zIndex: 50, minWidth: "180px",
          boxShadow: "0 8px 24px rgba(0,0,0,0.4)",
        }}>
          {[
            { label: "⚡ Open in VS Code",    action: () => openInEditor("vscode") },
            { label: "⚡ Open in Cursor",     action: () => openInEditor("cursor") },
            { label: "📋 Copy deep link",     action: () => { copyShareLink(); setShowMenu(false); } },
          ].map((item) => (
            <button
              key={item.label}
              onClick={item.action}
              style={{
                display: "block", width: "100%", textAlign: "left",
                padding: "7px 10px", background: "transparent",
                border: "none", borderRadius: "4px",
                color: "#8898a8", fontSize: "11px",
                cursor: "pointer", fontFamily: "inherit",
                transition: "all 0.15s",
              }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.background = "#1a2d40";
                (e.target as HTMLElement).style.color = "#e8f4ff";
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.background = "transparent";
                (e.target as HTMLElement).style.color = "#8898a8";
              }}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}

      {/* Not installed hint */}
      {status === "error" && (
        <span style={{ fontSize: "10px", color: "#ff6666" }}>
          Extension not installed?{" "}
          <a
            href="vscode:extension/branchdebug.branchdebug"
            style={{ color: "#4af0c4" }}
          >
            Install it
          </a>
        </span>
      )}
    </div>
  );
}


/**
 * Updated result card with deep link button integrated
 */
export function SuspectCard({
  suspect,
  analysisId,
  rank,
}: {
  suspect:    Suspect;
  analysisId: string;
  rank:       number;
}) {
  const confidenceColor = { High: "#ff4444", Medium: "#ffaa00", Low: "#44aaff" }[suspect.confidence];
  const confidenceBg    = { High: "rgba(255,68,68,0.1)", Medium: "rgba(255,170,0,0.1)", Low: "rgba(68,170,255,0.1)" }[suspect.confidence];

  return (
    <div style={{
      background: "#0d1520", border: "1px solid #1a2535",
      borderLeft: `3px solid ${confidenceColor}`,
      borderRadius: "8px", padding: "16px 18px",
    }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "10px", gap: "8px", flexWrap: "wrap" }}>
        <div>
          <span style={{ color: "#e8f4ff", fontSize: "13px", fontWeight: 600 }}>{suspect.file}</span>
          <span style={{ color: "#4a6070", fontSize: "12px" }}> :: </span>
          <span style={{ color: "#4af0c4", fontSize: "12px", fontFamily: "monospace" }}>{suspect.function}()</span>
          {suspect.line && (
            <span style={{ color: "#3a5060", fontSize: "11px", marginLeft: "6px" }}>
              line {suspect.line}
            </span>
          )}
        </div>
        <span style={{
          background: confidenceBg, color: confidenceColor,
          border: `1px solid ${confidenceColor}40`,
          borderRadius: "4px", padding: "2px 10px",
          fontSize: "10px", letterSpacing: "1px", textTransform: "uppercase",
        }}>
          {suspect.confidence}
        </span>
      </div>

      {/* Change summary */}
      <div style={{
        background: "#080c10", borderRadius: "5px", padding: "8px 12px",
        fontSize: "11px", color: "#4a8060", marginBottom: "10px",
        borderLeft: "2px solid #1a3020", fontFamily: "monospace",
      }}>
        {suspect.change}
      </div>

      {/* Mechanism */}
      <p style={{ margin: "0 0 10px", fontSize: "12px", color: "#7a9aaa", lineHeight: "1.7" }}>
        {suspect.mechanism}
      </p>

      {/* Deep link button */}
      <OpenInEditorButton suspect={suspect} analysisId={analysisId} />
    </div>
  );
}
