/**
 * BranchDebug Extension Tests
 * ============================
 * Tests URI parsing, path resolution, and link generation.
 * Run: npm test
 */

import * as assert from "assert";
import * as path from "path";
import * as os from "os";
import { ConfigManager } from "../configManager";

suite("URI Parsing", () => {

  test("builds correct deep link", () => {
    const link = ConfigManager.buildDeepLink({
      file:       "payments/validator.py",
      line:       142,
      confidence: "High",
      mechanism:  "Threshold change causes rejection of valid cards",
      fn:         "validate_card",
      analysisId: "abc123",
    });

    assert.ok(link.startsWith("branchdebug://open?"));
    assert.ok(link.includes("file=payments%2Fvalidator.py") || link.includes("file=payments/validator.py"));
    assert.ok(link.includes("line=142"));
    assert.ok(link.includes("confidence=High"));
    assert.ok(link.includes("analysis=abc123"));
  });

  test("deep link survives round-trip encode/decode", () => {
    const mechanism = "Reducing threshold from 1.2 → 0.8 causes earlier yield";
    const link = ConfigManager.buildDeepLink({
      file:       "planning/yield_policy.py",
      line:       88,
      confidence: "High",
      mechanism,
    });

    const url      = new URL(link.replace("branchdebug://", "http://open/"));
    const decoded  = decodeURIComponent(url.searchParams.get("mechanism") ?? "");
    assert.strictEqual(decoded, mechanism);
  });

  test("deep link with line range", () => {
    const link = ConfigManager.buildDeepLink({
      file:       "src/auth.ts",
      line:       50,
      endLine:    55,
      confidence: "Medium",
    });

    assert.ok(link.includes("line=50"));
    assert.ok(link.includes("endLine=55"));
  });
});


suite("Path Resolution", () => {

  test("resolves relative path under root", () => {
    // Simulate the resolution logic
    const root    = "/Users/jasmine/myproject";
    const relFile = "payments/validator.py";
    const result  = path.join(root, relFile);

    assert.strictEqual(result, "/Users/jasmine/myproject/payments/validator.py");
  });

  test("strips a/ b/ prefixes from git diff paths", () => {
    const stripGitPrefix = (f: string) => f.replace(/^[ab]\//, "");

    assert.strictEqual(stripGitPrefix("a/payments/validator.py"), "payments/validator.py");
    assert.strictEqual(stripGitPrefix("b/src/auth.ts"),           "src/auth.ts");
    assert.strictEqual(stripGitPrefix("payments/validator.py"),   "payments/validator.py");
  });

  test("handles absolute paths passed as file", () => {
    const stripGitPrefix = (f: string) => f.replace(/^[ab]\//, "");
    const root    = "/Users/jasmine/myproject";
    const relFile = "b/payments/validator.py";
    const clean   = stripGitPrefix(relFile);
    const result  = path.join(root, clean);

    assert.strictEqual(result, "/Users/jasmine/myproject/payments/validator.py");
  });
});


suite("Confidence Colors", () => {

  const STYLES: Record<string, string> = {
    High:   "rgba(255, 68, 68, 0.12)",
    Medium: "rgba(255, 170, 0, 0.10)",
    Low:    "rgba(68, 170, 255, 0.08)",
  };

  test("all confidence levels have styles", () => {
    ["High", "Medium", "Low"].forEach((level) => {
      assert.ok(STYLES[level], `Missing style for ${level}`);
    });
  });

  test("High confidence is red", () => {
    assert.ok(STYLES["High"].includes("255, 68, 68"));
  });

  test("Medium confidence is amber", () => {
    assert.ok(STYLES["Medium"].includes("255, 170, 0"));
  });

  test("Low confidence is blue", () => {
    assert.ok(STYLES["Low"].includes("68, 170, 255"));
  });
});
